base_micros
===========

Number of microseconds since the program started.

Parameters
----------

| Param name | Description | Type     |
 ------------|-------------|----------
