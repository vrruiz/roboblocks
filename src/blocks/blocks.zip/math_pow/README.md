math_pow
========

Returns number 1 to the power of number 2.

Parameters
----------

| Param name | Description | Type     |
 ------------|-------------|----------
| param1     | Base | `Number` |
| param2     | Exponent | `Number` |
