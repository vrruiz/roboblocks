math_min
========

Returns the minimum value of the two input numbers.

Parameters
----------

| Param name | Description | Type     |
 ------------|-------------|----------
| param1     | Number 1 | `Number` |
| param2     | Number 2 | `Number` |
