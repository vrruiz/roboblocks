base_delay_microseconds
=======================

Delay the program execution a specific amount of time (in microseconds).

Parameters
----------

| Param name | Description | Type     |
 ------------|-------------|----------
| time     | Amount of time | `Number` |
