inout_analog_write
==========

Initializes the pseudo-random number generator, causing it to start at an arbitrary point in its random sequence.

Parameters
----------

| Param name | Description | Type     |
 ------------|-------------|----------
| NUM     | Number to generate the Seed | `Number` |